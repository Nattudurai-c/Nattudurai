package com.example.regform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.se.omapi.Session;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.ArrayList;
import java.util.Properties;

public class view extends AppCompatActivity {

    Button request;

    ListView list1;
    ArrayList<String> title = new ArrayList<String>();
    ArrayAdapter arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        SQLiteDatabase db = openOrCreateDatabase("studentdb", Context.MODE_PRIVATE, null);

        list1 = findViewById(R.id.list);
        final Cursor c = db.rawQuery("select * from student", null);
        int id = c.getColumnIndex("id");
        int name = c.getColumnIndex("name");
        int food = c.getColumnIndex("food");
        int qty = c.getColumnIndex("quantity");
        int loc = c.getColumnIndex("location");
        title.clear();


        arrayAdapter = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, title);
        list1.setAdapter(arrayAdapter);

        final ArrayList<student> stud = new ArrayList<student>();

        if (c.moveToFirst()) {
            do {
                student student = new student();
                student.id = c.getString(id);
                student.name = c.getString(name);
                student.food = c.getString(food);
                student.quantity = c.getString(qty);
                student.location = c.getString(loc);

                stud.add(student);
                title.add(c.getString(id) + " \t " + c.getString(name) + " \t " + c.getString(food) + " \t " + c.getString(qty) + " \t " + c.getString(loc));

            } while (c.moveToNext());
            arrayAdapter.notifyDataSetChanged();
            list1.invalidateViews();
        }
    }

    }
