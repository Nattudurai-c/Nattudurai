package com.example.regform;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2,ed3,ed4;
    Button bt1,bt2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=findViewById(R.id.name);
        ed2=findViewById(R.id.course);
        ed3=findViewById(R.id.fee);
        ed4=findViewById(R.id.loc);
        bt1=findViewById(R.id.submit);
        bt2=findViewById(R.id.view);


        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),view.class);
                startActivity(i);
            }
        });

        bt1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
//
                if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
                    NotificationChannel channel =new NotificationChannel("My notification","My notification",NotificationManager.IMPORTANCE_DEFAULT);
                    NotificationManager manager = getSystemService(NotificationManager.class);
                    manager.createNotificationChannel(channel);
                }
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this,"My notification");
                builder.setContentTitle("Successfully Donated");
                builder.setContentText("Thank you for Donating ");
                builder.setSmallIcon(R.drawable.ic_launcher_background) ;
                builder.setAutoCancel(true);

                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity.this);
                managerCompat.notify(1,builder.build());

                insert();



            }
        });
    }


    public void insert(){
        try {
            String name=ed1.getText().toString();
            String food=ed2.getText().toString();
            String quantity=ed3.getText().toString();
            String location=ed4.getText().toString();

            SQLiteDatabase db=openOrCreateDatabase("studentdb", Context.MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS student(id INTEGER PRIMARY KEY AUTOINCREMENT,name VARCHAR,food VARCHAR,quantity VARCHAR, location VARCHAR)");

            String sql="insert into student(name,food,quantity,location) values(?,?,?,?)";
            SQLiteStatement statement= db.compileStatement(sql);
            statement.bindString(1,name);
            statement.bindString(2,food);
            statement.bindString(3,quantity);
            statement.bindString(4,location);

            statement.execute();
            Toast.makeText(this, "succesfully recorded",Toast.LENGTH_LONG).show();



        }

        catch (Exception ex){
            Toast.makeText(this, "failed",Toast.LENGTH_LONG).show();

        }
    }
}
