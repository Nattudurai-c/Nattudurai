package com.example.regform;

public class student {
    String id;
    String name;
    String food;
    String quantity;
    String location;
    String title;
}